
package br.edu.ifpr;

import java.sql.Connection;
import jdbc.Conexao;

public class Main {

    public static void main(String[] args) {

        try (Connection conexao = Conexao.getInstancia().conectar()) {

            System.out.println("Conexao com o banco realizada com sucesso!");

        } catch (Exception e) {

            System.out.println("Erro ao conectar com o banco!");
            e.printStackTrace();
        }
    }
}
