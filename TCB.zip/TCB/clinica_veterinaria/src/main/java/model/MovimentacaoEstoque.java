package model;

import java.time.LocalDate;

public class MovimentacaoEstoque {

    private int idMovimentacao;
    private String tipo;
    private int quantidade;
    private LocalDate data;
    private String descricao;
    private int idProduto;

    public MovimentacaoEstoque() {
    }

    public MovimentacaoEstoque(int idMovimentacao,
            String tipo, int quantidade,
            LocalDate data, String descricao,
            int idProduto) {
        this.idMovimentacao = idMovimentacao;
        this.tipo = tipo;
        this.quantidade = quantidade;
        this.data = data;
        this.descricao = descricao;
        this.idProduto = idProduto;
    }

    public int getIdMovimentacao() {
        return idMovimentacao;
    }

    public void setIdMovimentacao(int idMovimentacao) {
        this.idMovimentacao = idMovimentacao;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getIdProduto() {
        return idProduto;
    }

    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }
}