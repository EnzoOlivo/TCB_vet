
package model;

import java.time.LocalDate;
import java.time.LocalTime;

public class Consulta {

    private int idConsulta;
    private LocalDate data;
    private LocalTime horario;
    private String motivo;
    private String observacoes;
    private String diagnostico;
    private String prescricao;
    private String status;
    private int idPet;
    private int idVeterinario;

    public Consulta() {
    }

    public Consulta(int idConsulta, LocalDate data, LocalTime horario,
            String motivo, String observacoes, String diagnostico,
            String prescricao, String status, int idPet,
            int idVeterinario) {

        this.idConsulta = idConsulta;
        this.data = data;
        this.horario = horario;
        this.motivo = motivo;
        this.observacoes = observacoes;
        this.diagnostico = diagnostico;
        this.prescricao = prescricao;
        this.status = status;
        this.idPet = idPet;
        this.idVeterinario = idVeterinario;
    }

    public int getIdConsulta() {
        return idConsulta;
    }

    public void setIdConsulta(int idConsulta) {
        this.idConsulta = idConsulta;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHorario() {
        return horario;
    }

    public void setHorario(LocalTime horario) {
        this.horario = horario;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public String getObservacoes() {
        return observacoes;
    }

    public void setObservacoes(String observacoes) {
        this.observacoes = observacoes;
    }

    public String getDiagnostico() {
        return diagnostico;
    }

    public void setDiagnostico(String diagnostico) {
        this.diagnostico = diagnostico;
    }

    public String getPrescricao() {
        return prescricao;
    }

    public void setPrescricao(String prescricao) {
        this.prescricao = prescricao;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getIdPet() {
        return idPet;
    }

    public void setIdPet(int idPet) {
        this.idPet = idPet;
    }

    public int getIdVeterinario() {
        return idVeterinario;
    }

    public void setIdVeterinario(int idVeterinario) {
        this.idVeterinario = idVeterinario;
    }
}
