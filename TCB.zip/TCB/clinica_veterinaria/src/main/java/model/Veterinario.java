package model;

public class Veterinario {

    private int idVeterinario;
    private String nome;
    private String cpf;
    private String telefone;
    private String crmv;
    private String especialidade;

    public Veterinario() {
    }

    public Veterinario(int idVeterinario, String nome,
            String cpf, String telefone,
            String crmv, String especialidade) {
        this.idVeterinario = idVeterinario;
        this.nome = nome;
        this.cpf = cpf;
        this.telefone = telefone;
        this.crmv = crmv;
        this.especialidade = especialidade;
    }

    public int getIdVeterinario() {
        return idVeterinario;
    }

    public void setIdVeterinario(int idVeterinario) {
        this.idVeterinario = idVeterinario;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getCrmv() {
        return crmv;
    }

    public void setCrmv(String crmv) {
        this.crmv = crmv;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }
}