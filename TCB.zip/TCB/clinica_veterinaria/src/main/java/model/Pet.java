
package model;

import java.time.LocalDate;

public class Pet {

    private int idPet;
    private String nome;
    private String especie;
    private String raca;
    private LocalDate dataNascimento;
    private int idadeEstimada;
    private String unidadeIdade;
    private String sexo;
    private double pesoEstimado;
    private int idCliente;

    public Pet() {
    }

    public Pet(int idPet, String nome, String especie, String raca,
            LocalDate dataNascimento, int idadeEstimada,
            String unidadeIdade, String sexo, double pesoEstimado,
            int idCliente) {

        this.idPet = idPet;
        this.nome = nome;
        this.especie = especie;
        this.raca = raca;
        this.dataNascimento = dataNascimento;
        this.idadeEstimada = idadeEstimada;
        this.unidadeIdade = unidadeIdade;
        this.sexo = sexo;
        this.pesoEstimado = pesoEstimado;
        this.idCliente = idCliente;
    }

    public int getIdPet() {
        return idPet;
    }

    public void setIdPet(int idPet) {
        this.idPet = idPet;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEspecie() {
        return especie;
    }

    public void setEspecie(String especie) {
        this.especie = especie;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public int getIdadeEstimada() {
        return idadeEstimada;
    }

    public void setIdadeEstimada(int idadeEstimada) {
        this.idadeEstimada = idadeEstimada;
    }

    public String getUnidadeIdade() {
        return unidadeIdade;
    }

    public void setUnidadeIdade(String unidadeIdade) {
        this.unidadeIdade = unidadeIdade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public double getPesoEstimado() {
        return pesoEstimado;
    }

    public void setPesoEstimado(double pesoEstimado) {
        this.pesoEstimado = pesoEstimado;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }
}
