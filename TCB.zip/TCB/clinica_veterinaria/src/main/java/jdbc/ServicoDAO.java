
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import model.Servico;

public class ServicoDAO {

    public void inserir(Servico servico) {

        String sql = "INSERT INTO SERVICO (nome, descricao, valor) "
                + "VALUES (?, ?, ?)";

        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            conexao = Conexao.getInstancia().conectar();
            stmt = conexao.prepareStatement(sql);

            stmt.setString(1, servico.getNome());
            stmt.setString(2, servico.getDescricao());
            stmt.setDouble(3, servico.getValor());

            stmt.executeUpdate();

            System.out.println("Serviço cadastrado com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar serviço!");
            e.printStackTrace();
        }
    }
}
