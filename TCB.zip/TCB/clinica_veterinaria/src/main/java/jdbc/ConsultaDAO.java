
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import model.Consulta;

public class ConsultaDAO {

    public void inserir(Consulta consulta) {

        String sql = "INSERT INTO CONSULTA "
                + "(data, horario, motivo, observacoes, diagnostico, "
                + "prescricao, status, id_pet, id_veterinario) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.getInstancia().conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setDate(1, java.sql.Date.valueOf(consulta.getData()));
            stmt.setTime(2, java.sql.Time.valueOf(consulta.getHorario()));
            stmt.setString(3, consulta.getMotivo());
            stmt.setString(4, consulta.getObservacoes());
            stmt.setString(5, consulta.getDiagnostico());
            stmt.setString(6, consulta.getPrescricao());
            stmt.setString(7, consulta.getStatus());
            stmt.setInt(8, consulta.getIdPet());
            stmt.setInt(9, consulta.getIdVeterinario());

            stmt.executeUpdate();

            System.out.println("Consulta cadastrada com sucesso!");

        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar consulta!");
            e.printStackTrace();
        }
    }
}
