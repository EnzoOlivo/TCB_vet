
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import model.MovimentacaoEstoque;

public class MovimentacaoEstoqueDAO {

    public void inserir(MovimentacaoEstoque movimentacaoEstoque) {

        String sql = "INSERT INTO MOVIMENTACAO_ESTOQUE "
                + "(tipo, quantidade, data, descricao, id_produto) "
                + "VALUES (?, ?, ?, ?, ?)";

        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            conexao = Conexao.getInstancia().conectar();
            stmt = conexao.prepareStatement(sql);

            stmt.setString(1, movimentacaoEstoque.getTipo());
            stmt.setInt(2, movimentacaoEstoque.getQuantidade());
            stmt.setDate(3, java.sql.Date.valueOf(movimentacaoEstoque.getData()));
            stmt.setString(4, movimentacaoEstoque.getDescricao());
            stmt.setInt(5, movimentacaoEstoque.getIdProduto());

            stmt.executeUpdate();

            System.out.println("Movimentação cadastrada com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar movimentação!");
            e.printStackTrace();
        }
    }
}
