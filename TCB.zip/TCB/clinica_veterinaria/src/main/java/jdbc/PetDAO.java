
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import model.Pet;

public class PetDAO {

    public void inserir(Pet pet) {

        String sql = "INSERT INTO PET "
                + "(nome, especie, raca, data_nascimento, idade_estimada, "
                + "unidade_idade, sexo, peso_estimado, id_cliente) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conexao = Conexao.getInstancia().conectar();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {

            stmt.setString(1, pet.getNome());
            stmt.setString(2, pet.getEspecie());
            stmt.setString(3, pet.getRaca());

            if (pet.getDataNascimento() != null) {
                stmt.setDate(4, java.sql.Date.valueOf(pet.getDataNascimento()));
            } else {
                stmt.setNull(4, Types.DATE);
            }

            stmt.setInt(5, pet.getIdadeEstimada());
            stmt.setString(6, pet.getUnidadeIdade());
            stmt.setString(7, pet.getSexo());
            stmt.setDouble(8, pet.getPesoEstimado());
            stmt.setInt(9, pet.getIdCliente());

            stmt.executeUpdate();

            System.out.println("Pet cadastrado com sucesso!");

        } catch (SQLException e) {
            System.out.println("Erro ao cadastrar pet!");
            e.printStackTrace();
        }
    }
}
