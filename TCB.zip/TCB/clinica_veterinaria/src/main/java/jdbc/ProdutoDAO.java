
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import model.Produto;

public class ProdutoDAO {

    public void inserir(Produto produto) {

        String sql = "INSERT INTO PRODUTO "
                + "(nome, descricao, categoria, valor, quantidade_estoque) "
                + "VALUES (?, ?, ?, ?, ?)";

        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            conexao = Conexao.getInstancia().conectar();
            stmt = conexao.prepareStatement(sql);

            stmt.setString(1, produto.getNome());
            stmt.setString(2, produto.getDescricao());
            stmt.setString(3, produto.getCategoria());
            stmt.setDouble(4, produto.getValor());
            stmt.setInt(5, produto.getQuantidadeEstoque());

            stmt.executeUpdate();

            System.out.println("Produto cadastrado com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar produto!");
            e.printStackTrace();
        }
    }
}
