
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import model.Veterinario;

public class VeterinarioDAO {

    public void inserir(Veterinario veterinario) {

        String sql = "INSERT INTO VETERINARIO "
                + "(nome, cpf, telefone, crmv, especialidade) "
                + "VALUES (?, ?, ?, ?, ?)";

        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            conexao = Conexao.getInstancia().conectar();
            stmt = conexao.prepareStatement(sql);

            stmt.setString(1, veterinario.getNome());
            stmt.setString(2, veterinario.getCpf());
            stmt.setString(3, veterinario.getTelefone());
            stmt.setString(4, veterinario.getCrmv());
            stmt.setString(5, veterinario.getEspecialidade());

            stmt.executeUpdate();

            System.out.println("Veterinário cadastrado com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar veterinário!");
            e.printStackTrace();
        }
    }
}
