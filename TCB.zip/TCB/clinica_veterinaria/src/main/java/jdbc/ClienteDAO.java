
package jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import model.Cliente;

public class ClienteDAO {

    public void inserir(Cliente cliente) {

        String sql = "INSERT INTO CLIENTE (nome, cpf, telefone, email, endereco) "
                + "VALUES (?, ?, ?, ?, ?)";

        Connection conexao = null;
        PreparedStatement stmt = null;

        try {
            conexao = Conexao.getInstancia().conectar();
            stmt = conexao.prepareStatement(sql);

            stmt.setString(1, cliente.getNome());
            stmt.setString(2, cliente.getCpf());
            stmt.setString(3, cliente.getTelefone());
            stmt.setString(4, cliente.getEmail());
            stmt.setString(5, cliente.getEndereco());

            stmt.executeUpdate();

            System.out.println("Cliente cadastrado com sucesso!");

        } catch (Exception e) {
            System.out.println("Erro ao cadastrar cliente!");
            e.printStackTrace();
        }
    }
}
