package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {
    private String URL = "jdbc:mysql://localhost:3306/veterinaria";
    private String USUARIO = "root";
private String SENHA = "paodebatata";

    public Conexao() {

    }

    public static Conexao getInstancia(){
        return new Conexao();
    }
    public Connection conectar() throws SQLException{
        return DriverManager.getConnection(URL, USUARIO, SENHA);
    }
    
}

